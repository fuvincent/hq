#include "fun.h"
/***************************************************
 *查找删除行，遇见删除行，把行号赋值给变量num_empty
 *					并立即返回。
 * ***************************************************/
void line_empty(FILE *fp,int line,int *num)
{
	int i,j;
	int flag = 1;  
	char buf[124] = {0};
	fseek(fp,0,SEEK_SET);
	for(i = 1; i <= line; i++ )
	{
		if(fgets(buf,sizeof(buf),fp) != NULL)
		{
			for(j = 0; j < strlen(buf);j++)
			{
				if(buf[j] != FLAG_DEL)
				{
					flag = 0;
				}
				else
				{
					flag = 1;
				}
					break;
			}
			if(flag)
			{
				*num = i;
				break;
			}
		}
		else 
		{
			perror("fail to fgets");
		}
	}
	
}
/**************************************
 *
 *功能：查看文件的总行数
 *返回值：文件的总行数lin
 * ***********************************/
int line_total(FILE* fp)
{
	char ch ;
	int lin = 0;
	while ((ch = fgetc(fp)) != EOF)
	{
		if (ch == '\n')
		{
			lin++;
		}
	}
	return lin;
}
/****************************************************
 *			功能：插入员工信息的子函数
 ***************************************************/
int insert(FILE *fp,infor *c)
{
	fprintf(fp,"%10s%20s%5c%15s%15s\n",c->id,c->name,c->sex,c->num,c->date);
	return 0;
}
int insert_empty(FILE *fp, infor *c	)
{
	fprintf(fp,"%10s%20s%5c%15s%15s",c->id,c->name,c->sex,c->num,c->date);
	return 0;
}
/**********************************
 *功能：插入操作。
 *有删除行在删除行插入
 *没有则在文件的下行插入
 * *******************************/
void info_insert(FILE *fp,infor *employee)
{
	char buf[10] = {"he"};
	if(num_empty != 0)
	{
		fseek(fp,0,SEEK_SET);
		while(fgets(buf,sizeof(buf),fp) != NULL)
		{
			if(strncmp(buf,"a",1) == 0)
			{
				puts("yes");
				//printf("strlen(buf) = %d\n",strlen(buf));
				fseek(fp,-strlen(buf),SEEK_CUR);
				/*********hole file**********/
				
				insert_empty(fp,employee);
			}
		}

	}
	else
	{
		insert(fp,employee);
	}
}

/***********************************************
 *
 *删除子函数：根据ID查找员工信息，若输入的ID不存在,
 则打印提示信息若输入的ID存在，则将相应的信息全部用a覆盖
 *
 * ***********************************************/
int server_delete(FILE *fp,char id[])
{
	int i;
	char buff[128] = {0};
	fseek(fp,0,SEEK_SET);
	while(NULL != fgets(buff,sizeof(buff),fp))
	{
	//	puts("hehe");
		if(NULL != strstr(buff,id))
		{
			printf("=\n");
			printf("%d\n",strlen(buff));
			fseek(fp,-strlen(buff),SEEK_CUR);
			for(i = 0; i < strlen(buff)-1;i++)
			{
				if('a' != fputc('a',fp))
				{
					perror("fail to fputc a");
				}
			}
			return 0;
		}

	}
	return -1;
}
							
/*******************************
 *
 *删除员工信息函数
 *
 * ***************************/
void info_del(FILE *fp,char id[])
{
	if(-1 == server_delete(fp,id))
	{
		perror("fail to delete info");
	}

}
/********************************************
 *
 *员工信息修改子函数
 *
 * *********************************************/
int server_modify(FILE *fp,infor *c)
{

	char tmp[16] = {0};
	strcpy(tmp,c->id);
	puts(tmp);
	char buff[128] = {0};
	fseek(fp,0,SEEK_SET);
	while(NULL != fgets(buff,sizeof(buff),fp))
	{
		//puts("buff");
		if(NULL != strstr(buff,tmp))
		{
		//	puts("modify");
			fseek(fp,-strlen(buff),SEEK_CUR);
			fprintf(fp,"%10s%20s%5c%15s%15s",c->id,c->name,c->sex,c->num,c->date);
			return 0;
		}
	}

	return -1;
}

/*************员工信息修改函数*************/
int infor_modify(FILE *fp,infor *c)
{
	if(-1 == server_modify(fp,c))
	{
		perror("fail to modify");
	}
}

/*************查询操作子函数**************/
int server_search(FILE *fp,infor *c)
{
	char tmp[16] = {0};
	strcpy(tmp,c->id);
	puts(tmp);
	char buff[128] = {0};

	fseek(fp,0,SEEK_SET);

	while(NULL != fgets(buff,sizeof(buff),fp))
	{
		if(NULL != strstr(buff,tmp))
		{
			puts("strstr");
			puts(buff);
			buff[strlen(buff)-1] = '\0';
			strtok_fun(buff,c);
			return 0;
		}
	}
	return -1;
}

/***************查询操作函数********************************/
void infor_search(FILE *fp,infor *c)
{
	if(-1 == server_search(fp,c))
	{
		perror("fail to search");
	}
}

/*********拆解员工信息函数，并将其存入结构体中**********/
void strtok_fun(char buff[],infor *c)
{
	char *p;
	p = strtok(buff," ");
	//puts(p);
	strcpy(c->id,p);
	p = strtok(NULL," ");
	strcpy(c->name,p);
	p = strtok(NULL," ");
	strcpy(&(c->sex),p);	
	p = strtok(NULL," ");
	strcpy(c->num,p);
	p = strtok(NULL," ");
	strcpy(c->date,p);
//	printf("%s-%s-%c-%s-%s\n",c->id,c->name,c->sex,c->num,c->date);

#if 0 
	while(p = strtok(NULL," "))
	{
		puts(p);
	//	strcpy(c->name,p)
	}
#endif
}
