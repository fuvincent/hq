#ifndef _FUN_C_
#define _FUN_C_

#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include "employee.h"
#define  FLAG_DEL 'a'

extern int num_empty;
extern infor employee;
void line_empty(FILE *fp,int line,int *num);
int line_total(FILE *fp);
int insert(FILE *fp,infor *c);
int insert_empty(FILE *fp, infor *c	);
void info_insert(FILE *fp,infor *employee);
int server_delete(FILE *fp,char id[]);
void info_del(FILE *fp,char id[]);
int server_modify(FILE *fp,infor *c);
int infor_modify(FILE *fp,infor *c);
int server_search(FILE *fp,infor *c);
void infor_search(FILE *fp,infor *c);
void strtok_fun(char buff[],infor *c);

#endif
