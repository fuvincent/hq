#include <stdio.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <stdlib.h>
#include <string.h>
#include "employee.h"
#include "fun.h"

int num_empty;
infor employee;

#if 0
void line_empty(FILE *fp,int line,int *num);
int line_total(FILE *fp);
int insert(FILE *fp,infor *c);
int insert_empty(FILE *fp, infor *c	);
void info_insert(FILE *fp,infor *employee);
int server_delete(FILE *fp,char id[]);
void info_del(FILE *fp,char id[]);
int server_modify(FILE *fp,infor *c);
int infor_modify(FILE *fp,infor *c);
int server_search(FILE *fp,infor *c);
void infor_search(FILE *fp,infor *c);
void strtok_fun(char buff[],infor *c);

#endif 
infor employee1 = {
	"20150001",
	"lililili",
	'W',
	"110",
	"2015.03.24"
};
infor employee2 = {
	"2015001",
	"lili",
	'F',
	"110",
	"2015.03.02"
};


int main(int argc, const char *argv[])
{
	FILE *fp;
	int line;
	if((fp  = fopen("stu.txt","r+")) < 0)
 	{
		perror("fail to open");
		return -1;
	}

	line = line_total(fp);
	printf("line_total = %d\n",line);
	
	line_empty(fp,line,&num_empty);
	printf("line_empty = %d\n",num_empty);
	
	//info_insert(fp,&employee1);
	
//	info_del(fp,"2015001");

//	infor_modify(fp,&employee2);
infor_search(fp,&employee2);
return 0;
}
