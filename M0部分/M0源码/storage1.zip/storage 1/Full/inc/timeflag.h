#ifndef __TIMEFLAG_H
#define __TIMEFLAG_H

void ScanTimeCnt(void);
void ScanTimeFlag(void);
void InitTimeFlag(void);	

#endif 

