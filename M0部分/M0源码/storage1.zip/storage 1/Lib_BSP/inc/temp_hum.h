#ifndef __TEMP_HUM_H
#define __TEMP_HUM_H

void TimeScanDHT11(void);
void InitDHT11(void);

#endif

