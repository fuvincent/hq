#ifndef __MYADC_H
#define __MYADC_H

void ScanMyAdc(void);
void InitMyAdc(void);

#endif
