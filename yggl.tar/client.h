#ifndef CLIENT_H
#define CLIENT_H
#include "comm.h"
extern void add();
extern void del();
extern void modify();
extern void search();
extern void quit();
extern void printmainmenu();
#endif
